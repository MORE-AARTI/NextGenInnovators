export const CHAT_KNOWLEDGE_BASE = [
    {
        keywords: ["hi", "hello", "hey", "start"],
        response: "Hello! I'm your Skincare Assistant. Ask me about skin types, routine, or products!",
    },
    {
        keywords: ["dry", "flaky", "itchy"],
        response: "For dry skin, hydration is key! Use a cream-based cleanser, hyaluronic acid serum, and a rich moisturizer. Drinking plenty of water helps too.",
    },
    {
        keywords: ["oily", "greasy", "shiny", "oil"],
        response: "Managing oily skin involves using a foaming cleanser, oil-free moisturizer, and ingredients like Salicylic Acid or Niacinamide.",
    },
    {
        keywords: ["acne", "pimple", "breakout"],
        response: "Breakouts can be tough! Try tea tree oil or benzoyl peroxide for spot treatment. Keep your face clean and avoid touching it.",
    },
    {
        keywords: ["wrinkle", "aging", "lines"],
        response: "For anti-aging, sunscreen is your best friend! Retinol (vitamin A) is also excellent for reducing fine lines. Stay hydrated!",
    },
    {
        keywords: ["sun", "spf", "protection"],
        response: "Always wear broad-spectrum SPF 30 or higher, even on cloudy days. Reapply every 2 hours if you're outdoors.",
    },
    {
        keywords: ["bye", "goodbye", "thanks", "thank you"],
        response: "You're welcome! Take care of your skin and have a glowing day!",
    },
];

export const DEFAULT_RESPONSE = "I'm not sure about that. Could you try asking about 'dry skin', 'oily skin', 'acne', or 'sun protection'?";
