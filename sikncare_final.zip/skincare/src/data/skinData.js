import { Droplets, Sun, Wind, Activity, Utensils, Smile } from "lucide-react";

export const SKIN_TYPES = {
    NORMAL: "Normal",
    DRY: "Dry",
    OILY: "Oily",
    COMBINATION: "Combination",
};

export const SKIN_DATA = {
    [SKIN_TYPES.NORMAL]: {
        description: "Your skin is well-balanced, neither too oily nor too dry.",
        characteristics: [
            "No severe sensitivity",
            "Barely visible pores",
            "Radiant complexion",
        ],
        routine: [
            { step: "Cleansing", product: "Gentle, sulfate-free cleanser", time: "AM/PM" },
            { step: "Toning", product: "Rose water or alcohol-free toner", time: "AM/PM" },
            { step: "Moisturizing", product: "Lightweight lotion or hydrating cream", time: "AM/PM" },
            { step: "Sun Protection", product: "Broad-spectrum SPF 30+", time: "AM" },
        ],
        remedies: [
            { name: "Honey & Yogurt Mask", type: "Ayurvedic", instruction: "Mix 1 tbsp honey with 1 tbsp yogurt. Apply for 15 mins." },
            { name: "Rose Water Splash", type: "Daily", instruction: "Splash cold rose water on face every morning." },
        ],
        diet: [
            "Include Vitamin C rich fruits like oranges and strawberries.",
            "Stay hydrated with at least 8 glasses of water.",
            "Balanced diet with proteins and healthy fats.",
        ],
        yoga: [
            { name: "Surya Namaskar", benefit: "Improves blood circulation and overall glow." },
            { name: "Sarvangasana", benefit: "Promotes blood flow to the face." },
        ],
    },
    [SKIN_TYPES.DRY]: {
        description: "Your skin produces less sebum than normal skin and lacks moisture.",
        characteristics: [
            "Rough or dull texture",
            "Red patches",
            "Less elastic skin",
            "More visible lines",
        ],
        routine: [
            { step: "Cleansing", product: "Cream-based or oil cleanser", time: "AM/PM" },
            { step: "Toning", product: "Hydrating toner without alcohol", time: "AM/PM" },
            { step: "Serum", product: "Hyaluronic acid serum", time: "AM/PM" },
            { step: "Moisturizing", product: "Rich cream or facial oil", time: "AM/PM" },
            { step: "Sun Protection", product: "Moisturizing SPF 30+", time: "AM" },
        ],
        remedies: [
            { name: "Aloe Vera & Honey", type: "Ayurvedic", instruction: "Mix fresh aloe gel with honey. Apply for 20 mins." },
            { name: "Milk Cream Massage", type: "Ayurvedic", instruction: "Massage face with fresh milk cream (malai) before bath." },
        ],
        diet: [
            "Eat foods high in Omega-3 fatty acids like walnuts and flaxseeds.",
            "Avocados and olive oil are great for healthy fats.",
            "Limit caffeine and alcohol as they dehydrate skin.",
        ],
        yoga: [
            { name: "Matsyasana (Fish Pose)", benefit: "Improves thyroid function and hormone balance." },
            { name: "Bhujangasana (Cobra Pose)", benefit: "Increases oxygen to skin cells." },
        ],
    },
    [SKIN_TYPES.OILY]: {
        description: "Your skin produces excess sebum, leading to a shiny appearance.",
        characteristics: [
            "Enlarged pores",
            "Dull or shiny, thick complexion",
            "Blackheads, pimples, or other blemishes",
        ],
        routine: [
            { step: "Cleansing", product: "Foaming or gel cleanser with salicylic acid", time: "AM/PM" },
            { step: "Toning", product: "Witch hazel or tea tree toner", time: "AM/PM" },
            { step: "Moisturizing", product: "Oil-free, gel-based moisturizer", time: "AM/PM" },
            { step: "Sun Protection", product: "Matte finish SPF 30+", time: "AM" },
        ],
        remedies: [
            { name: "Multani Mitti Pack", type: "Ayurvedic", instruction: "Mix Fuller's earth with rose water. Apply until dry." },
            { name: "Neem Paste", type: "Ayurvedic", instruction: "Apply neem paste on acne prone areas." },
        ],
        diet: [
            "Avoid fried and sugary foods.",
            "Green leafy vegetables and fiber-rich fruits.",
            "Cucumber and watermelon for hydration.",
        ],
        yoga: [
            { name: "Kapalbhati", benefit: "Detoxifies the body and improves skin radiance." },
            { name: "Halasana (Plow Pose)", benefit: "Improves digestion, reducing acne." },
        ],
    },
    [SKIN_TYPES.COMBINATION]: {
        description: "Your skin can be dry or normal in some areas and oily in others, such as the T-zone.",
        characteristics: [
            "Oily T-zone (nose, forehead, chin)",
            "Dry or normal checks",
            "Pores that look larger than normal",
        ],
        routine: [
            { step: "Cleansing", product: "Gentle gel cleanser", time: "AM/PM" },
            { step: "Toning", product: "Balancing toner", time: "AM/PM" },
            { step: "Moisturizing", product: "Lightweight lotion (oil-free for T-zone)", time: "AM/PM" },
            { step: "Sun Protection", product: "Lightweight SPF 30+", time: "AM" },
        ],
        remedies: [
            { name: "Honey & Lemon", type: "Ayurvedic", instruction: "Apply honey on dry areas and lemon juice on oily areas." },
            { name: "Curd & Turmeric", type: "Ayurvedic", instruction: "Mix curd with pinch of turmeric. Apply for 10 mins." },
        ],
        diet: [
            "Include probiotics like yogurt.",
            "Whole grains and lean proteins.",
            "Berries for antioxidants.",
        ],
        yoga: [
            { name: "Ardha Matsyendrasana", benefit: "Helps in detoxification." },
            { name: "Paschimottanasana", benefit: "Reduces stress which can trigger imbalances." },
        ],
    },
};
