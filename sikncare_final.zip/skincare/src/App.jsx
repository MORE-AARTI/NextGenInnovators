import React, { useState } from 'react';
import Layout from './components/layout/Layout';
import Hero from './components/features/Hero';
import ImageUpload from './components/features/ImageUpload';
import SkinAnalysisResult from './components/features/SkinAnalysisResult';
import Chatbot from './components/features/Chatbot';

function App() {
  const [analysisImage, setAnalysisImage] = useState(null);

  const handleStartAnalysis = () => {
    document.getElementById('analyze')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleAnalyze = (image) => {
    setAnalysisImage(image);
    // Smooth scroll to results after a short delay
    setTimeout(() => {
      document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <Layout>
      <Hero onStart={handleStartAnalysis} />

      <div className="bg-white rounded-3xl shadow-xl overflow-hidden mb-20 max-w-5xl mx-auto" id="results">
        <ImageUpload onAnalyze={handleAnalyze} />
        {analysisImage && <SkinAnalysisResult image={analysisImage} />}
      </div>

      <Chatbot />
    </Layout>
  );
}

export default App;
