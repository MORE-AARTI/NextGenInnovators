import React from 'react';
import { Heart } from 'lucide-react';

const Footer = () => {
    return (
        <footer className="bg-dark text-white py-8 mt-16">
            <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="text-center md:text-left">
                    <h3 className="text-lg font-bold mb-2">GlowGuide AI</h3>
                    <p className="text-gray-300 text-sm">Your personalized path to radiant skin.</p>
                </div>

                <div className="flex items-center gap-1 text-sm text-gray-300">
                    <span>Made with</span>
                    <Heart className="h-4 w-4 text-accent fill-accent" />
                    <span>for healthy skin</span>
                </div>

                <div className="flex gap-4 text-sm text-gray-400">
                    <a href="#" className="hover:text-white transition-colors">Privacy</a>
                    <a href="#" className="hover:text-white transition-colors">Terms</a>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
