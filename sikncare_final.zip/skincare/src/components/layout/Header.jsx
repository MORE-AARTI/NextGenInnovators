import React from 'react';
import { Sparkles, Menu, X } from 'lucide-react';

const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    return (
        <header className="fixed w-full top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm transition-all duration-300">
            <div className="container mx-auto px-4 py-3 flex justify-between items-center">
                <div className="flex items-center gap-2 text-primary">
                    <Sparkles className="h-6 w-6" />
                    <span className="text-xl font-bold tracking-wide">GlowGuide AI</span>
                </div>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex gap-8 text-dark font-medium">
                    <a href="#" className="hover:text-primary transition-colors">Home</a>
                    <a href="#analyze" className="hover:text-primary transition-colors">Analyze Skin</a>
                    <a href="#about" className="hover:text-primary transition-colors">About</a>
                </nav>

                {/* Mobile Menu Button */}
                <button
                    className="md:hidden text-dark hover:text-primary"
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                    {isMenuOpen ? <X /> : <Menu />}
                </button>
            </div>

            {/* Mobile Navigation */}
            {isMenuOpen && (
                <nav className="md:hidden bg-white border-t border-gray-100 absolute w-full left-0 py-4 flex flex-col items-center gap-4 shadow-lg animate-fade-in">
                    <a href="#" className="text-dark hover:text-primary font-medium" onClick={() => setIsMenuOpen(false)}>Home</a>
                    <a href="#analyze" className="text-dark hover:text-primary font-medium" onClick={() => setIsMenuOpen(false)}>Analyze Skin</a>
                    <a href="#about" className="text-dark hover:text-primary font-medium" onClick={() => setIsMenuOpen(false)}>About</a>
                </nav>
            )}
        </header>
    );
};

export default Header;
