import React from 'react';
import Header from './Header';
import Footer from './Footer';

const Layout = ({ children }) => {
    return (
        <div className="min-h-screen flex flex-col bg-gradient-to-br from-light to-white">
            <Header />
            <main className="flex-grow pt-20 px-4 container mx-auto">
                {children}
            </main>
            <Footer />
        </div>
    );
};

export default Layout;
