import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Hero = ({ onStart }) => {
    return (
        <section className="relative overflow-hidden py-20 px-4 md:py-32">
            <div className="container mx-auto max-w-6xl flex flex-col md:flex-row items-center gap-12">

                {/* Text Content */}
                <div className="flex-1 text-center md:text-left z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                    >
                        <span className="inline-block px-4 py-2 rounded-full bg-primary/20 text-dark font-medium text-sm mb-6">
                            ✨ #1 AI Skincare Assistant
                        </span>
                        <h1 className="text-4xl md:text-6xl font-bold text-dark leading-tight mb-6">
                            Discover Your Perfect <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-dark">
                                Glow Routine
                            </span>
                        </h1>
                        <p className="text-gray-600 text-lg md:text-xl mb-8 max-w-lg mx-auto md:mx-0">
                            Upload a selfie and let our AI analyze your skin type. Get personalized Ayurvedic remedies, diet plans, and yoga tips instantly.
                        </p>

                        <button
                            onClick={onStart}
                            className="group bg-dark text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-primary hover:text-dark transition-all duration-300 shadow-lg hover:shadow-xl flex items-center gap-2 mx-auto md:mx-0"
                        >
                            Analyze My Skin <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                        </button>
                    </motion.div>
                </div>

                {/* Visual/Image */}
                <div className="flex-1 relative">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="relative z-10"
                    >
                        <div className="relative w-full aspect-square max-w-md mx-auto">
                            <div className="absolute inset-0 bg-accent/20 rounded-full filter blur-3xl animate-pulse"></div>
                            <img
                                src="https://images.unsplash.com/photo-1596472537353-3d8e3d6f102c?auto=format&fit=crop&q=80&w=1000"
                                alt="Glowing Skin"
                                className="w-full h-full object-cover rounded-3xl shadow-2xl relative z-10 border-4 border-white"
                            />

                            {/* Floating Cards */}
                            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-xl flex items-center gap-3 animate-slide-up">
                                <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                                    <Sparkles size={20} />
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500">Analysis</p>
                                    <p className="font-bold text-dark">98% Accuracy</p>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>

            {/* Background Decor */}
            <div className="absolute top-0 right-0 w-1/3 h-full bg-secondary/30 -z-0 skew-x-12 transform origin-top-right"></div>
        </section>
    );
};

export default Hero;
