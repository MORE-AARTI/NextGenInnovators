import React, { useState } from 'react';
import { Upload, X, Loader2, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ImageUpload = ({ onAnalyze }) => {
    const [preview, setPreview] = useState(null);
    const [isDragging, setIsDragging] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);

    const handleFile = (file) => {
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    };

    const handleChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            handleFile(e.target.files[0]);
        }
    };

    const startAnalysis = () => {
        setAnalyzing(true);
        // Simulate API delay
        setTimeout(() => {
            setAnalyzing(false);
            onAnalyze(preview);
        }, 2000); // 2 seconds delay
    };

    const clearImage = () => {
        setPreview(null);
    };

    return (
        <section id="analyze" className="py-16 px-4 bg-white">
            <div className="container mx-auto max-w-3xl text-center">
                <h2 className="text-3xl font-bold text-dark mb-4">Analyze Your Skin</h2>
                <p className="text-gray-600 mb-8">Upload a clear selfie for the best results.</p>

                {!preview ? (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`border-2 border-dashed rounded-3xl p-10 transition-colors cursor-pointer ${isDragging ? 'border-primary bg-primary/5' : 'border-gray-300 hover:border-primary'
                            }`}
                        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={handleDrop}
                        onClick={() => document.getElementById('fileInput').click()}
                    >
                        <input
                            type="file"
                            id="fileInput"
                            className="hidden"
                            accept="image/*"
                            onChange={handleChange}
                        />
                        <div className="flex flex-col items-center gap-4 text-gray-500">
                            <div className="h-20 w-20 bg-gray-50 rounded-full flex items-center justify-center">
                                <Upload className="h-8 w-8 text-primary" />
                            </div>
                            <div>
                                <p className="text-lg font-medium text-dark">Click to upload or drag & drop</p>
                                <p className="text-sm">SVG, PNG, JPG or GIF (max. 3MB)</p>
                            </div>
                        </div>
                    </motion.div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="relative bg-gray-50 rounded-3xl p-4 shadow-lg border border-gray-100"
                    >
                        <div className="relative aspect-[3/4] md:aspect-video w-full max-h-[500px] overflow-hidden rounded-2xl">
                            <img src={preview} alt="Upload Preview" className="w-full h-full object-contain bg-black/5" />

                            {/* Scanning Overlay Effect */}
                            {analyzing && (
                                <div className="absolute inset-0 bg-primary/10 z-10 flex flex-col items-center justify-center">
                                    <div className="absolute top-0 left-0 w-full h-1 bg-primary/50 shadow-[0_0_15px_rgba(160,196,157,1)] animate-[scan_2s_linear_infinite]"></div>
                                    <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full flex items-center gap-3 shadow-xl">
                                        <Loader2 className="animate-spin text-primary" />
                                        <span className="font-medium text-dark">Analyzing skin texture...</span>
                                    </div>
                                </div>
                            )}
                        </div>

                        {!analyzing && (
                            <div className="mt-6 flex gap-4 justify-center">
                                <button
                                    onClick={clearImage}
                                    className="px-6 py-2 rounded-full border border-gray-300 text-gray-600 hover:bg-gray-50 transition-colors flex items-center gap-2"
                                >
                                    <X size={18} /> Cancel
                                </button>
                                <button
                                    onClick={startAnalysis}
                                    className="px-8 py-2 rounded-full bg-primary text-dark font-bold hover:bg-green-400 transition-colors shadow-lg flex items-center gap-2"
                                >
                                    <Camera size={18} /> Start Analysis
                                </button>
                            </div>
                        )}
                    </motion.div>
                )}
            </div>

            <style jsx global="true">{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          20% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
        </section>
    );
};

export default ImageUpload;
