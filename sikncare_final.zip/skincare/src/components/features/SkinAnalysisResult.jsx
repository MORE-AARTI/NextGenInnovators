import React, { useEffect, useState } from 'react';
import { SKIN_TYPES } from '../../data/skinData';
import Recommendations from './Recommendations';
import { CheckCircle, Loader } from 'lucide-react';

const SkinAnalysisResult = ({ image }) => {
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Mock Analysis Logic
        const analyze = () => {
            // randomly select a skin type for prototype
            const types = Object.values(SKIN_TYPES);
            const randomType = types[Math.floor(Math.random() * types.length)];
            setResult(randomType);
            setLoading(false);
        };

        if (image) {
            setLoading(true);
            // Simulate processing time
            setTimeout(analyze, 1500);
        }
    }, [image]);

    if (loading) {
        return (
            <div className="py-20 text-center">
                <Loader className="animate-spin h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-600">Analyzing your skin structure...</h3>
            </div>
        );
    }

    return (
        <div className="animate-fade-in">
            <div className="bg-dark/5 py-8 text-center mb-8">
                <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full font-bold mb-2">
                    <CheckCircle size={20} /> Analysis Complete
                </div>
                <h2 className="text-3xl font-bold text-dark">
                    Your Skin Type is <span className="text-primary underline decoration-wavy">{result}</span>
                </h2>
            </div>

            <Recommendations skinType={result} />
        </div>
    );
};

export default SkinAnalysisResult;
