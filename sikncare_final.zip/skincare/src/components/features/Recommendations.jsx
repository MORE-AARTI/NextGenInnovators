import React, { useState } from 'react';
import { SKIN_DATA } from '../../data/skinData';
import { Droplets, Sun, Activity, Utensils, Smile } from 'lucide-react';
import { motion } from 'framer-motion';

const Recommendations = ({ skinType }) => {
    const data = SKIN_DATA[skinType];
    const [activeTab, setActiveTab] = useState('routine');

    if (!data) return null;

    const tabs = [
        { id: 'routine', label: 'Skincare Routine', icon: Droplets },
        { id: 'remedies', label: 'Home Remedies', icon: Sun },
        { id: 'diet', label: 'Diet & Nutrition', icon: Utensils },
        { id: 'yoga', label: 'Yoga & Exercise', icon: Activity },
    ];

    return (
        <section id="results" className="py-16 px-4 bg-light/50">
            <div className="container mx-auto max-w-5xl">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-12"
                >
                    <span className="text-primary font-bold tracking-wider uppercase text-sm">Your Personalized Plan</span>
                    <h2 className="text-4xl font-bold text-dark mt-2 mb-4">Recommendations for {skinType} Skin</h2>
                    <p className="text-gray-600 max-w-2xl mx-auto">{data.description}</p>
                </motion.div>

                {/* Tabs */}
                <div className="flex flex-wrap justify-center gap-4 mb-10">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${activeTab === tab.id
                                    ? 'bg-primary text-dark shadow-lg scale-105'
                                    : 'bg-white text-gray-500 hover:bg-gray-50'
                                }`}
                        >
                            <tab.icon size={18} />
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Content Area */}
                <div className="bg-white rounded-3xl p-8 shadow-xl min-h-[400px]">
                    {activeTab === 'routine' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="grid gap-6 md:grid-cols-2"
                        >
                            {data.routine.map((item, idx) => (
                                <div key={idx} className="flex items-start gap-4 p-4 rounded-xl hover:bg-light transition-colors border border-gray-100">
                                    <div className="bg-primary/20 p-3 rounded-full text-dark font-bold">
                                        {idx + 1}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg text-dark">{item.step}</h4>
                                        <p className="text-gray-500 text-sm mb-1">{item.time}</p>
                                        <p className="text-primary font-medium">{item.product}</p>
                                    </div>
                                </div>
                            ))}
                        </motion.div>
                    )}

                    {activeTab === 'remedies' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="grid gap-6 md:grid-cols-2"
                        >
                            {data.remedies.map((item, idx) => (
                                <div key={idx} className="bg-secondary/20 p-6 rounded-2xl border border-secondary/50">
                                    <div className="flex items-center gap-3 mb-3">
                                        <SunWrapper />
                                        <h4 className="font-bold text-xl text-dark">{item.name}</h4>
                                    </div>
                                    <span className="inline-block px-3 py-1 bg-white rounded-full text-xs font-bold text-gray-500 mb-3 uppercase tracking-wide">
                                        {item.type}
                                    </span>
                                    <p className="text-gray-700 leading-relaxed">{item.instruction}</p>
                                </div>
                            ))}
                        </motion.div>
                    )}

                    {activeTab === 'diet' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                        >
                            <ul className="space-y-4">
                                {data.diet.map((item, idx) => (
                                    <li key={idx} className="flex items-center gap-4 p-4 bg-green-50 rounded-xl border border-green-100">
                                        <div className="h-2 w-2 rounded-full bg-green-500"></div>
                                        <span className="text-gray-700 text-lg">{item}</span>
                                    </li>
                                ))}
                            </ul>
                        </motion.div>
                    )}

                    {activeTab === 'yoga' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="grid gap-6 md:grid-cols-2"
                        >
                            {data.yoga.map((item, idx) => (
                                <div key={idx} className="text-center p-6 border border-gray-100 rounded-2xl hover:shadow-md transition-shadow">
                                    <h4 className="font-bold text-xl text-dark mb-2">{item.name}</h4>
                                    <p className="text-gray-600">{item.benefit}</p>
                                </div>
                            ))}
                        </motion.div>
                    )}
                </div>
            </div>
        </section>
    );
};

const SunWrapper = () => <div className="p-2 bg-yellow-100 rounded-full text-yellow-600"><Smile size={20} /></div>;

export default Recommendations;
